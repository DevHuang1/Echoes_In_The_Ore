# Asteria space backdrop frames

This folder holds ten 1774 × 887 PNG frames used by the ship walkaround's looping animated background. Each frame shifts the same starfield farther right, opposite the ship's left-facing bow, to read as forward travel. The runtime sprite is centered on the map and scaled to provide camera overscan.

Regenerate them from `art/overview/asteria_space_backdrop_source.png` with:

```sh
godot --headless --path . --script tools/build_space_backdrop_frames.gd
```

The sequence is loaded by `scripts/ship/space_backdrop.gd` at 10 frames per second.
